﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;

// Allgemeine Informationen über eine Assembly werden über die folgende 
// Attributgruppe gesteuert. Ändern Sie diese Attributwerte, um die Informationen zu ändern,
// die einer Assembly zugeordnet sind.
[assembly: AssemblyTitle("Allmystery")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("mchomer")]
[assembly: AssemblyProduct("Allmystery")]
[assembly: AssemblyCopyright("mchomer ©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


// Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly 
// für COM-Komponenten unsichtbar. Wenn Sie auf einen Typ in dieser Assembly von 
// COM aus zugreifen müssen, legen Sie das ComVisible-Attribut für diesen Typ auf "true" fest.
[assembly: ComVisible(false)]

// Die folgende GUID ist für die ID der typelib, wenn dieses Projekt für COM verfügbar gemacht wird
[assembly: Guid("448870b8-e0eb-41c9-8e42-fe90e5f5eaf5")]

// Versionsinformationen für eine Assembly bestehen aus den folgenden vier Werten:
//
//      Hauptversion
//      Nebenversion 
//      Buildnummer
//      Revision
//
// Sie können alle Werte angeben oder die Standardwerte für Revisions- und Buildnummer verwenden 
// übernehmen, indem Sie "*" wie folgt verwenden:
[assembly: AssemblyVersion("1.1.0")]
[assembly: AssemblyFileVersion("1.1.0")]
[assembly: NeutralResourcesLanguageAttribute("de-DE")]
